package BasePack1;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class Base {
	public static WebDriver driver;
  @Test
  public void f() {
	  System.setProperty("Webdriver.driver.chromedriver", "C:\\Users\\shash\\OneDrive\\Desktop\\Automation classes\\chromedriver-win64\\chromedriver-win64\\chromedriver.exe");
	  driver= new ChromeDriver();
	  driver.manage().window().maximize();
  }
}
