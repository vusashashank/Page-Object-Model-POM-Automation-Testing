package TestPOM;

import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.Test;

import BasePack.BaseClass;
import CodingScript.codingclass;

public class Testing extends BaseClass{
	@Test
	public void Login() {
	codingclass C= PageFactory.initElements(driver, codingclass.class);
	C.login();
	}

}
