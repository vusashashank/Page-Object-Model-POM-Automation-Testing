package CodingScript;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.FindBy;

import BasePack.BaseClass;
import TestPOM.Testing;

public class codingclass extends Testing {
	@FindBy  (xpath="//input[@name='txtUserName']")WebElement UN;
	@FindBy  (xpath="//input[@name='txtPassword']")WebElement PWD;
	@FindBy  (xpath="//input[@name='Submit']")WebElement SB;
	
   public void login() {
	   
	   driver.get("http://127.0.0.1/orangehrm-2.5.0.2/login.php");
	   UN.sendKeys("selenium");
	   PWD.sendKeys("cypress");
	   SB.click();
	   
	   
   }
	

}
