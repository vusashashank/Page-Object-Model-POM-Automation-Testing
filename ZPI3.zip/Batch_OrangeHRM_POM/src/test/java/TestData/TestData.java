package TestData;

import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.Test;

import BasePack1.Base;
import Codeing.codingPart;

public class TestData extends Base{

  @Test
  public void login() {
	  codingPart c= PageFactory.initElements(driver, codingPart.class);
	  c.login();
	  
	  
  }
}
